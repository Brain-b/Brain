<?php
// Please Read ResultsConfig.php Before doing anything

$Token = 'Your-Bot-Token'; // Your telegram bot token make it via BotFather after you done making it Send /start to it else you cant receive Results 
$ChatID = ''; // Your Chat ID get it from @username_to_id_bot
?>