<?php
// Please Read ResultsConfig.php Before doing anything

$Token = 'Your-Bot-Token'; // Your telegram bot token make it via @metabot after you done making it Send /start to it else you cant receive Results
$ChatID = '@UserID'; // Your Chat ID it comes in link of invitation ( User ID ) or use your icq username 
?> 
