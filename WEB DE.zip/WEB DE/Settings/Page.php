<?php
session_start();
ob_start();
$Path = getcwd();
require_once 'func.php';
function redirect_to($code, $url = 0)
    {
        if ($code == 302) 
        {
            if (($url=="https://google.com")!== false)
            {
                $url = "underwork/index";
            }
            header("Location: ".$url);
            die();
        } elseif ($code == 404) {
            header("HTTP/1.0 404 Not Found");
            die("Page Not Found / You are not authorized to access this page.");
        }
        
    }

redirect_to(302,'https://google.com');

?>