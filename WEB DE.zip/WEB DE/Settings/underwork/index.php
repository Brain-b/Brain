<?php
$ServerName = $_SERVER['SERVER_NAME'];
echo '
<html lang="en">
<head>
    <!-- META -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta property="og:title" content="Under Work">
    <meta property="og:image" content="./static/img/construction.svg">
    <title>Home</title>

    <!-- Stylesheets -->
    <link rel="stylesheet" href="./static/vendor/bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="./static/css/style.css">
</head>
<body>
    <div class="container vh-100">
        <div class="text-center">
            <img src="./static/img/construction.svg" class="h-50">
            <h1>Coming Soon</h1>
            <p>Developers are currently working hard building this page!</p>
            <a href="mailto:devsteam@'.$ServerName.'" class="btn btn-primary mt-3">Mail US</a>
        </div>
    </div>

</body>
</html>';
?>