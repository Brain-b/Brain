<?php
session_start();
ob_start();
function SaveBotsLogs($Cause)
{
    $PathBad = getcwd();
    $ua = $_SESSION['UA'];
    $ip = getIPAddress();
    $PathR = $PathBad.'/Bots-Logs/Bots.txt';
    $Path = $PathR;
    $Text = '✔️✔️✔️{'.$Cause.'}✔️✔️✔️'.PHP_EOL;
    $Text .= '🥊🥊🥊 BOT FUCKED 🥊🥊🥊 '.PHP_EOL;
    $Text .= 'IP: '.$ip.PHP_EOL;
    $Text .= 'User-Agent: '.$ua.PHP_EOL;
    $Text .= 'Date: '.date("Y/m/d").PHP_EOL;
    $Text .= '✔️✔️✔️{'.$Cause.'}✔️✔️✔️'.PHP_EOL;
    if (file_exists($Path)) 
    {
        $FileOpen = fopen($Path,'a+');
        fwrite($FileOpen, $Text);
        fclose($FileOpen);
    }else
    {
        $FileOpen = fopen($Path,'w');
        fwrite($FileOpen, $Text);
        fclose($FileOpen);
    }
}

?>