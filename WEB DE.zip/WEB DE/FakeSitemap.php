<?php
session_start();
ob_start();
$Path = getcwd();
require_once 'Settings/Main_AntiBots.php';
require_once 'Settings/Settings.php';
$ServerName = $_SERVER['SERVER_NAME'];
$data = '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">'.PHP_EOL;
$data .= '<sitemap>'.PHP_EOL;
$data .= '<loc>https://'.$ServerName.'/underwork</loc>'.PHP_EOL;
$data .= '</sitemap>'.PHP_EOL;
$data .= '</urlset>'.PHP_EOL;
file_put_contents('sitemap.xml',$data);

?>